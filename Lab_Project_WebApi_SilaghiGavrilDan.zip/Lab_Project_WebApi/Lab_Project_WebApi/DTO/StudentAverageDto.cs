﻿namespace Lab_Project_WebApi.DbContext
{
    public class StudentAverageDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public double AverageGrade { get; set; }
    }
}
