﻿namespace Lab_Project_WebApi.DbContext
{
    public class UpdateSubjectDto
    {
        public string Name { get; set; }
    }

    public class SubjectDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
