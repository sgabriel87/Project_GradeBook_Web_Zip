﻿using System.ComponentModel.DataAnnotations;

namespace Lab_Project_WebApi.DbContext
{
    public class CreateMarkDto
    {
        [Range(1, 10)]
        public int Value { get; set; }
        public int SubjectId { get; set; }
    }
}
