﻿namespace Lab_Project_WebApi.DbContext
{
    public class CreateSubjectDto
    {
        public string Name { get; set; }
    }
}
